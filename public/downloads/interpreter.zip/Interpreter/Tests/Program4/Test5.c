/***************************************************
 * CS460: Programming Assignment 4: Test Program 5 *
 ***************************************************/

char announcement[2048];


procedure main (void)
{
  char name[100];
  char announcement[64];
}


function bool my_function (char byte)
{
  int i, j;
  bool found_something;

  return found_something;
}


procedure my_procedure (int i, int j, int k)
{
}

