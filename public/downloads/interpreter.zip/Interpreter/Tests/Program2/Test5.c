// ***************************************************
// * CS460: Programming Assignment 2: Test Program 5 *
// ***************************************************
procedure main (void)
{
  int counter;

  1counter = 2;
  printf ("counter = %d\n", 1counter);
}
