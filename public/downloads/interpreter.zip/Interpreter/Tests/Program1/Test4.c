// ***************************************************
// * CS460: Programming Assignment 1: Test Program 4 *
// ***************************************************
procedure main (void)//)
{
/**/int counter; 

/**/counter = 100 / 2;
/**/printf ("counter = %d\n", counter);
/**/printf ("/* Will this string be displayed? */\n");
/**/printf ("// Will this string be displayed?\n");
}
