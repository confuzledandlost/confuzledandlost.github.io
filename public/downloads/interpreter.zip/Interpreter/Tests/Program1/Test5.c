/****************************************************
 *  CS460: Programming Assignment 1: Test Program 5 *
 ****************************************************/
procedure main (void)
{
  int counter; 
/*
  counter = 100 / 2;
}
