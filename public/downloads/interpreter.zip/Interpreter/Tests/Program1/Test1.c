// ***************************************************
// * CS460: Programming Assignment 1: Test Program 1 *
// ***************************************************
procedure main (void)
{
  int counter;

  counter = 2;
/* 
  counter = 100;
*/
  printf ("counter = %d\n", counter);
}
