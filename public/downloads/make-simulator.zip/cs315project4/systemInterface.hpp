// systemInterface.hpp


bool fileExists(std::string nameOfFile);
unsigned long timestampForFile(std::string nameOfFile);
bool executeCommand(std::string cmnd);
