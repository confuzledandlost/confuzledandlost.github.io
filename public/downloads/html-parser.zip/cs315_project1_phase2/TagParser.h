//
// Created by Brandon Robinson on 2/7/24.
//

#ifndef CS315_PROJECT1_PHASE2_TAGPARSER_H
#define CS315_PROJECT1_PHASE2_TAGPARSER_H

#include "Tokenizer.hpp"
#include "TraversableStack.h"
#include <map>
#include <vector>

using namespace std;

class TagParser {

public:
    TagParser();
    void parseTags(std::string nameOfInputFile);

private:
    TraversableStack stack;
    std::map<std::string, std::vector< std::pair<Token, Token> > > allTagLocations;

    void handleOpenTag(Tokenizer &, Token &);
    void handleCloseTag(Tokenizer &, Token &);
    void handleStandAloneCloseTag(Token &);
    void printWellFormedTags();
    void addToMap(pair<Token, Token> &);

};

#endif //CS315_PROJECT1_PHASE2_TAGPARSER_H