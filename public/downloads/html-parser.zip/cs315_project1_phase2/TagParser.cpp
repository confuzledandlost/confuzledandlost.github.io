//
// Created by Brandon Robinson on 2/7/24.
//

#include <iostream>
#include "TagParser.h"
using namespace std;

TagParser::TagParser() {}

void TagParser::parseTags(std::string nameOfInputFile) {
    Tokenizer tokenizer(nameOfInputFile);

    Token token = tokenizer.getToken();
    while (!token.endOfFile()) {
        if( token.isOpenTag() && !token.tagName().empty())
            handleOpenTag(tokenizer, token);
        else if( token.isCloseTag() )
            handleCloseTag(tokenizer, token);
        else if(token.isCloseAngleBracket() || token.isOpenTag()) {
            token.print();
            std::cout << (token.isCloseAngleBracket() ? " ignoring random close angle-bracket."
                                                    : " ignoring random open angle-bracket.") << std::endl;
        } else {
            token.print();
            std::cout << " unknown token."  << std::endl;
        }
        token = tokenizer.getToken();
    }

    // Empty the stack that's leftover and
    // Print the bad tags
    while (!stack.empty()) {
    stack.popLast().print();
    cout << " doesn't have a matching close tag. Will discard it.\n";
    }

    // Print the good tags
    printWellFormedTags();
}

void TagParser::handleOpenTag(Tokenizer &tokenizer, Token &token) {

    // Grab next token
    Token nextToken = tokenizer.getToken();

    // Throw it to handleStandAloneCloseTag if it's a standalone close tag
    if (nextToken.isCloseStandAloneTag()) {
        stack.addLast(token);
        handleStandAloneCloseTag(nextToken);
    }
    // Add it to the stack if it's a good token
    else if(nextToken.isCloseAngleBracket()) {
        stack.addLast(token);
    }
    // This is where putBack goes
    else {
        token.print();
        cout << " is missing a '>' or '/>'. Will discard it.\n";
        tokenizer.putBack(nextToken);
    }
}

void TagParser::handleCloseTag(Tokenizer &tokenizer, Token &token) {

    // Grab next token
    Token nextToken = tokenizer.getToken();

    // If it's a good complete tag...
    if(nextToken.isCloseAngleBracket()) {

        // Check if most recent token in stack is the matching open tag
        if (stack.last().tagName() == token.tagName()) {

            // Make a pair and put it on the map
            pair<Token, Token> newGoodPair = {stack.popLast(), token};
            addToMap(newGoodPair);
        }
        // Check if it even exists in the stack
        else if (stack.rmember(token.tagName())){
            token.print();
            cout << " closes while the following tags remain open.";
            stack.printBackwardUnit(token.tagName(), true);
            stack.rremove(token.tagName());
        }
        // Otherwise YEET
        else {
            token.print();
            cout << " (with close angle bracket " ;
            nextToken.print();
            cout << ") doesn't have a matching open tag. Will discard it.\n";
        }
    }
    // Put it back!
    else {
        token.print();
        cout << " is missing a '>' or '/>'. Will discard it.\n";
        tokenizer.putBack(nextToken);
    }
}
void TagParser::handleStandAloneCloseTag(Token &token) {

    // Make a pair out of the two tokens
    pair<Token, Token> currentPair = {stack.popLast(), token};

    // Add the pairs to the map
    addToMap(currentPair);

}

void TagParser::printWellFormedTags() {

    cout << "\nThe following is a list of well-formed HTML tags.\n";

    // Make iterator for traversing through map
    auto it = allTagLocations.begin();

    // While loop for printing the map's key/tag names
    while (it != allTagLocations.end()) {

        cout << '\n' << it->first << " appeared in the following ";
        if (it->second.size() > 1) {
            cout << it->second.size() << " locations.\n";
        }
        else {
            cout << "location.\n";
        }

        // For loop for printing pairs inside the vector
        for (int i = 0; i < it->second.size(); i++){
            cout << '\t';
            it->second.at(i).first.print();
            cout << " -- ";
            it->second.at(i).second.print();
            cout << endl;
        }

        // Don't forget to iterate the iterator!
        it++;
    }
}

void TagParser::addToMap(pair<Token, Token> &ourPair) {

    // Grab the tag name
    string tagName = ourPair.first.tagName();

    // Make an iterator and check to see if a key for the tag exists
    auto it = allTagLocations.find(tagName);

    // If it does, add ourPair to the existing tag vector
    if (it != allTagLocations.end()) {
        allTagLocations[tagName].push_back(ourPair);
    }
    else {  // Otherwise, make a new key for the tag and add the vector to it
        vector<pair<Token, Token>> newVector;
        newVector.push_back(ourPair);
        allTagLocations[tagName] = newVector;
    }
}