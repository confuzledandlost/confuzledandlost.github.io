//
// Created by Brandon Robinson on 2/7/24.
//

#include "TraversableStack.h"
#include <iostream>
using namespace std;


// Adds to the top of the stack
void TraversableStack::addLast(Token newLast) {
    tagNames.push_back(newLast);
}
// Pops the top element of the stack
Token TraversableStack::popLast() {
    Token popped(tagNames.back());
    tagNames.erase(tagNames.begin() + tagNames.size()-1);
    return popped;
}

// Returns the top element of the stack
Token TraversableStack::last() {return tagNames.back();}

// Performs a search from top to bottom
bool TraversableStack::rmember(const std::string& tag) {
    int i = tagNames.size()-1;

    while(i >= 0) {
        if(tagNames.at(i).tagName() == tag) {
            return true;
        }
        i--;
    }
    return false;
}

// Removes the last occurrence of a tag
void TraversableStack::rremove(const std::string& tag) {
    int i = tagNames.size()-1;

    // Look for the tag to remove
    while(i >= 0) {
        if(tagNames.at(i).tagName() == tag) {   // Found it
            tagNames.erase(tagNames.begin() + i);   // Yeet that
            break; // GTFO
        }
        i--;    // Decrement
    }
}

// Prints the stack backwards until it finds a specific tag
void TraversableStack::printBackwardUnit(const std::string& tag, bool indent) {

    for (int i = tagNames.size() - 1; i >= 0; i--) {
        if(tagNames.at(i).tagName() == tag) break;
        cout << '\n';
        if(indent) cout << '\t';
        tagNames.at(i).print();
    }
    cout << '\n';
}

// Return the number of items in the stack
size_t TraversableStack::size() {return tagNames.size();}

// Returns if the stack is empty
bool TraversableStack::empty() {return (tagNames.empty());}