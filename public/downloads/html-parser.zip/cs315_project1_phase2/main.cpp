
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <stack>
#include "TagParser.h"

int main(int argc, char *argv[]) {

    // File checking logic
    if( argc != 2 ) {  // we expect the name of the file as an argument to the program.
        std::cout << "usage: " << argv[0] << " nameOfAnInputFile" << std::endl;
        exit(1);
    }

    // Check if we can open the file
    std::ifstream inputStream;
    inputStream.open(argv[1], std::ios::in);    // open for reading
    if( ! inputStream.is_open()) {
        std::cout << "Unable top open " << argv[1] << ". Terminating...";
        std::cout << strerror(errno) << std::endl;
        exit(2);
    }

    // Close input file stream
    inputStream.close();

    // Create a tag parser object
    TagParser tagParser;

    // Parse through the tags
    tagParser.parseTags(argv[1]);

    // One more newline
    std::cout << '\n';

    return 0;
}