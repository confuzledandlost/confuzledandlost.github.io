//
// Created on 1/21/24.
//

#include <iostream>
#include "Tokenizer.hpp"

Tokenizer::Tokenizer(std::string name): lineNumber{1},
                                        charPosition{1},
                                        inputFileName{name} {
    inputStream.open(inputFileName, std::ios::in);  // open the input file. We will make sure that it is open in getToken.
}

bool Tokenizer::charOfInterest(char c) {
    // is c the initial (or the sole) character of a token?
    if (c == '<') {
        return true;
    }

    if (c == '>') {
        return true;
    }

    if (c == '/') {
        if (inputStream.peek() == '>') {
            return true;
        }
    }
    return false;   // you need to replace this with code that compares c with characters like '<', '>', etc.
}

Token Tokenizer::getToken() {
    // Char from input stream being analyzed
    char c;
    std::string tName = "";

    // Standard check to see if file is open
    if( ! inputStream.is_open()) {
        std::cout << "Tokenizer::getToken() called with a stream that is not open." << std::endl;
        std::cout << "Make sure that " << inputFileName << " exists and is readable. Terminating.";
        exit(2);
    }

    // Checks for non-chars of interest and
    // Updates char position as well as line number
    while( inputStream.get(c) && ! charOfInterest(c) ) {
        // keep track of the line number and the character position here.
        charPosition++;

        if (c == '\n') {
            lineNumber++;
        }
    }
    // New token object stores line number and char position
    Token token(lineNumber, charPosition);

    // Check if it's the end of the file
    if( inputStream.eof() ) {
        token.endOfFile() = true;
    }

    // Main char checks
    else if( c == '<' ) {
        charPosition++;

        // Check for backslash
        if (inputStream.peek() == '/') {
            charPosition++;
            inputStream.ignore();

            // If the first character isalpha...
            // Grab the whole tag name
            if (isalpha(inputStream.peek())) {
                tName += inputStream.get();
                charPosition++;
                while (isalpha(inputStream.peek()) || isdigit(inputStream.peek())) {
                    tName += inputStream.get();
                    charPosition++;
                }
            }
            // Make the token
            token.makeCloseTag(tName);
        }
        else {
            // If the first character isalpha...
            // Grab the whole tag name
            if (isalpha(inputStream.peek())) {
                tName += inputStream.get();
                charPosition++;
                while (isalpha(inputStream.peek()) || isdigit(inputStream.peek())) {
                    tName += inputStream.get();
                    charPosition++;
                }
            }
            // Make the token
            token.makeOpenTag(tName);
        }
    }
    else if( c == '>' ) {
        token.isCloseAngleBracket() = true;
        charPosition ++;
    }
    else if( c == '/') {
        if (inputStream.peek() == '>') {
            inputStream.ignore();
            token.isCloseStandAloneTag() = true;
            charPosition += 2;
        }
    }

    return token;
}

void Tokenizer::putBack(Token &token) {

    // Check for token type
    if (token.isCloseTag() || token.isCloseStandAloneTag()) {
        inputStream.unget();
        inputStream.unget();
        charPosition -= 2;
    }
    else if (token.isOpenTag()) {
        inputStream.unget();
        charPosition--;
    }

    // Put each character from the tag name back into the inputstream
    for (int i = 0; i < token.tagName().size(); i++) {
        inputStream.unget();
        charPosition--;
    }
}