//
// Created by Brandon Robinson on 2/7/24.
//

#ifndef CS315_PROJECT1_PHASE2_TRAVERSABLESTACK_H
#define CS315_PROJECT1_PHASE2_TRAVERSABLESTACK_H

#include "Tokenizer.hpp"
#include <vector>

class TraversableStack {

public:
    void addLast(Token); // add to the top of the stack
    Token popLast();     // pop the top element of the stack
    Token last();        // top element of the stack
    bool rmember(const std::string& tag);  // perform a search from top to bottom
    void rremove(const std::string& tag);  // remove the last occurrence of a tag.
    void printBackwardUnit(const std::string& tag, bool indent=false);
    size_t size();  // how many element are on the stack?
    bool empty();

private:
    std::vector<Token> tagNames;
};



#endif //CS315_PROJECT1_PHASE2_TRAVERSABLESTACK_H
