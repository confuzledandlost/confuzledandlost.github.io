Brandon Robinson

I have not included code in my solution to the project that I did not write, regardless of source.

I did not provide code, regardless of source, to any student in the class.

All features that are part of the project 1 phase 2 requirements have been implemented.