Brandon Robinson
November 13th 2024
CS-415: Algorithm Analysis
Dr. Ali Kooshesh

Project 2 Report

How to Run the Project

Compile and run the project with the following command:

./maze.x <num_rows> <num_columns> <pattern>

Requirements:

    Pattern must be between 0 and 4 (inclusive).
    Both num_rows and num_columns must be greater than 3.

Example:

./maze.x 8 8 2

The maze structure can vary based on the selected weight function, controlled by a third command-line argument. Here are the available patterns:

    Pattern 0 (Random Maze): Assigns random weights for a classic, unpredictable maze.
    Pattern 1 (Easy Columns): Sequentially increasing weights in each column, creating straightforward paths.
    Pattern 2 (Hard Columns): Assigns the longest possible path weights, forcing the solution to traverse through the most cells.
    Pattern 3 (Office Building): Binary weights (0 or 1), based on the previous edge weight, mimic a structured, office-like layout.
    Pattern 4 (Stairs): Weights depend on the parent vertex’s position (even x and y coordinates), creating stair-like patterns in the maze.


Runtime Analysis

I believe the runtime complexity of my maze generation solution has three main components:

    Graph Construction
    The maze is represented as a grid-based graph, where each cell corresponds to a vertex connected to its neighbors (up, down, left, right), with adjustments for edge cells. This step runs in O(rows × columns).

    Minimum Spanning Tree (MST) Generation
    Using Kruskal’s algorithm, the maze is built as an MST, ensuring all cells are reachable with a single path between any two points.
        With approximately E ≈ 2 × (rows × columns) edges, managed using a min-heap, the MST generation runs in O(E log E) or O(rows × columns × log(rows × columns)).

    Shortest Path Calculation
    After constructing the MST, the shortest path from the start to the end is calculated using graph traversal, which has a runtime of O(V + E) or O(rows × columns).

Overall Complexity
Since MST generation is the most computationally intensive step, the total runtime complexity is O(rows × columns × log(rows × columns)).
Maze Patterns

