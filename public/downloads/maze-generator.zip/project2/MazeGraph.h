//
// Created by brandon on 11/1/24.
//
#include <iostream>
#include <queue>
#include <vector>
#include <utility>
#include <cstdlib>
#include <ctime>
#include <unordered_set>
#include <cmath>

#ifndef MAZEGRAPH_H
#define MAZEGRAPH_H

// Forward declaration to fix a scope conflict
struct Vertex;

// Custom graph Edge struct
struct Edge {

    // Pointers to where edge is connected
    // And weight
    // Boolean if it's in the MST
    Vertex* a = nullptr;
    Vertex* b = nullptr;
    int weight = 0;
    bool isInMST = false;

};

// Custom graph node struct
struct Vertex{

    // Node/vertex attributes
    int label = 0;
    std::vector <Vertex*> neighbors;
    std::vector <Edge*> edges;
    bool wasVisited = false;
    Vertex* parent = this;

    // Function for printing a vertex node and its neighbors
    void printVertexNeighbors() {

        // Prints label
        std::cout << "\n" << this->label << " -> ";

        // Loop that cycles through neighbors and print their label
        for(int i = 0; i < this->neighbors.size(); i++) {
            std::cout << ' ' << this->neighbors.at(i)->label;
        }
    }

    // Function for printing a vertex node, it's edge weights and neighbors
    void printWeightNeighbors() {

        // Prints label
        std::cout << "\n" << this->label << " -> ";

        // Loop that cycles through neighbors, prints their edges and label
        for(int i = 0; i < this->neighbors.size(); i++) {
            std::cout << " -" << this->edges.at(i)->weight << '-' << this->neighbors.at(i)->label;

        }
    }
};

// Struct for our min-priority queue
struct lessThan {

    // Operator for doing the less than comparison
    bool operator() (const Edge* a, const Edge* b) {
        return a->weight > b->weight;
    }
};

class MazeGraph {
private:
    Vertex* start = nullptr;
    Vertex* end = nullptr;
    std::vector <Vertex*> vertexes;
    int numCols = 0;
    int numRows = 0;
    std::priority_queue<Edge*, std::vector<Edge*>, lessThan> edgeQueue;
    std::vector <Edge*> MST;
    std::vector <Vertex*> mazeSolution;
    int weightValue = 0;
    int prevEdgeWeight = 0;

public:
    Vertex* getStart() {return this->start;}
    Vertex* getEnd() {return this->end;}
    MazeGraph(int, int, int);
    ~MazeGraph();
    void print();
    void printWeight();
    void printQueue();
    void makeMST();
    void printMST();
    bool shortestPath(Vertex*);
    std::vector <Vertex*> getSolution() {return this->mazeSolution;}
    void printSolutionVector();
    void _union(Vertex* v1, Vertex* v2);
    Vertex* _find(Vertex*);
    void printEmptyGrid();
    void printSolutionGrid(bool);
    int generateWeight1();
    int generateWeight2(Vertex*, std::string);
    int generateWeight3();
    int generateWeight4(Vertex*);

};

#endif //MAZEGRAPH_H