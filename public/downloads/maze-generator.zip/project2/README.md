# Maze Generator

A C++ implementation of a maze generator and solver using graph theory concepts. This project creates mazes using different patterns and solves them using Kruskal's algorithm for Minimum Spanning Tree (MST) generation.

## Features

- Generate mazes with different patterns affecting difficulty and structure
- Visualize maze and solution path in a grid format
- Five unique maze patterns with different characteristics
- Efficient maze solving using graph algorithms
- Command-line interface for easy configuration

## Maze Patterns

The maze generator supports five different patterns:

1. **Random Maze (Pattern 0)**
   - Assigns random weights for a classic, unpredictable maze
   - Creates a traditional maze with varying difficulty

2. **Easy Columns (Pattern 1)**
   - Sequentially increasing weights in each column
   - Creates straightforward paths with predictable patterns

3. **Hard Columns (Pattern 2)**
   - Assigns the longest possible path weights
   - Forces the solution to traverse through the most cells
   - Creates challenging mazes with complex paths

4. **Office Building (Pattern 3)**
   - Uses binary weights (0 or 1)
   - Based on the previous edge weight
   - Mimics a structured, office-like layout

5. **Stairs (Pattern 4)**
   - Weights depend on the parent vertex's position
   - Creates stair-like patterns in the maze
   - Uses even x and y coordinates for weight determination

## Building the Project

### Prerequisites

- C++20 compatible compiler (g++ recommended)
- Make

### Compilation

```bash
make
```

This will create the executable `maze.x` in your current directory.

## Usage

Run the program with the following command:

```bash
./maze.x <num_rows> <num_columns> <pattern>
```

### Parameters

- `num_rows`: Number of rows in the maze (must be greater than 3)
- `num_columns`: Number of columns in the maze (must be greater than 3)
- `pattern`: Pattern value (0-4) to use for maze generation

### Example

```bash
./maze.x 8 8 2
```

This will generate an 8x8 maze using pattern 2 (Hard Columns).

## Runtime Analysis

The maze generation solution has three main components:

1. **Graph Construction**
   - Runtime: O(rows × columns)
   - Creates a grid-based graph where each cell corresponds to a vertex

2. **Minimum Spanning Tree (MST) Generation**
   - Runtime: O(rows × columns × log(rows × columns))
   - Uses Kruskal's algorithm with a min-heap
   - Ensures all cells are reachable with a single path

3. **Shortest Path Calculation**
   - Runtime: O(rows × columns)
   - Calculates the shortest path from start to end using graph traversal

## Project Structure

- `MazeGraph.h` - Header file containing class and structure definitions
- `MazeGraph.cpp` - Implementation of maze generation and solving algorithms
- `main.cpp` - Program entry point and command-line interface
- `Makefile` - Build configuration

## Implementation Details

The project uses several key data structures and algorithms:

- Graph representation using vertices and edges
- Union-Find data structure for MST generation
- Priority queue for edge weight management
- Depth-First Search for path finding
- Custom weight generation functions for different patterns

## License

This project is open source and available under the MIT License.

## Author

Brandon Robinson 