#include <iostream>

#include "MazeGraph.h"

int main(int argc, char *argv[]) {
    // Check if the correct number of arguments is provided
    if (argc < 3) { // argc should be 3 or 4: program name + 2 (or 3) arguments
        std::cerr << "Usage: " << argv[0] << " <num_rows> <num_columns> <pattern_value>(optional)\n";
        return 1; // Exit with an error code
    }

    // Parse the arguments
    int numRows = std::atoi(argv[1]);     // Convert argument 1 to an integer
    int numColumns = std::atoi(argv[2]); // Convert argument 2 to an integer
    int weightValue = 0;
    if (argc == 4) {
        weightValue = std::atoi(argv[3]); // Convert argument 3 to an integer
    }

    // Check for valid inputs
    if (numRows < 2 || numColumns < 2 || weightValue < 0) {
        std::cerr << "Error: Columns and Rows must be greater than 1\n"
                     "Pattern value must be a value from 0, to 4\n";
        return 1; // Exit with an error code
    }

    // Print the arguments (for verification)
    std::cout << "Number of rows: " << numRows << "\n";
    std::cout << "Number of columns: " << numColumns << "\n";
    std::cout << "Pattern Value: " << weightValue << "\n";

    // Create all of our nodes
    MazeGraph* maze_graph = new MazeGraph(numColumns, numRows, weightValue);

    // Print the adjacency list
    // maze_graph->print();
    // std::cout << "\n\n";
    // maze_graph->printWeight();

    // Print our priority queue
    //std::cout << "\n\n";
    //maze_graph->printQueue();

    // Create our MST
    maze_graph->makeMST();

    // Print new MSTadjacencyList
    // std::cout << "\n\n";
    // maze_graph->printWeight();

    // Create our solution
    maze_graph->shortestPath(maze_graph->getStart());

    // Print solution vector
    // std::cout << "\n\n";
    // maze_graph->printSolution();

    std::cout << "\nProduces the following Maze Graph:\n";

    // Print the MST/maze
    maze_graph->printSolutionGrid(false);

    std::cout << "\nThe solution contains the following vertexes:\n";
    maze_graph->printSolutionVector();

    // Print the Solution
    maze_graph->printSolutionGrid(true);


    return 0;
}
