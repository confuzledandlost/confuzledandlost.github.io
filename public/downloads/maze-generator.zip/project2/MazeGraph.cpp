//
// Created by brandon on 11/1/24.
//

#include "MazeGraph.h"

// Constructor for our maze
MazeGraph::MazeGraph(int cols, int rows, int weightValue) {

    time_t seed = time(0);

    // Seed the rand function
    srand(seed);

    // Create empty vertexes based on numCols and numRows
    this->numCols = cols;
    this->numRows = rows;
    this->weightValue = weightValue;

    // Outer loop for rows
    for (int i = 0; i < numRows; i++) {

        // Inner loop for columns
        for (int j = 0; j < numCols; j++) {

            // Create new vertex, assign a label (based on column/row position)
            // Push it into vertex list, delete old pointer
            Vertex* emptyVertex = new Vertex();
            emptyVertex->label = (i * numCols) + j;
            this->vertexes.push_back(emptyVertex);
        }
    }

    // Cycle through vertex list and assign neighbors/weights based on user input
    for (int i = 0; i < this->vertexes.size(); i++) {

        // Grab the next vertex in the list and make a pointer to it
        Vertex* currVertex = this->vertexes[i];

        // Check if we're at the last vertex
        if (currVertex->label == this->vertexes.size()-1) {break;} // Break if we are

        // Check if we're in the last row
        if (i < this->vertexes.size() - numCols) {

            // If we're not, then...
            // Check if we're in the last column
            if (!((i + 1) % (numCols) == 0)) {

                // If we're not, then...
                // Assign vertex to the right as a neighbor
                Vertex* rightVertex = this->vertexes[i + 1];
                currVertex->neighbors.push_back(rightVertex);
                // Assign vertex below as a neighbor
                Vertex* downVertex = this->vertexes[i + numCols];
                currVertex->neighbors.push_back(downVertex);
                // And vise-verse
                rightVertex->neighbors.push_back(currVertex);
                downVertex->neighbors.push_back(currVertex);

                // Create edges/assign weights
                // First right
                Edge* rightEdge = new Edge();
                rightEdge->a = currVertex;
                rightEdge->b = rightVertex;
                if (this->weightValue == 0) {
                    rightEdge->weight = rand() % 100;
                }
                else if (this->weightValue == 1) {
                    rightEdge->weight = this->generateWeight1();
                }
                else if (this->weightValue == 2) {
                    rightEdge->weight = this->generateWeight2(currVertex, "right");
                }
                else if (this->weightValue == 3) {
                    rightEdge->weight = this->generateWeight3();
                }
                else if (this->weightValue == 4) {
                    rightEdge->weight = this->generateWeight4(currVertex);
                }
                currVertex->edges.push_back(rightEdge);
                rightVertex->edges.push_back(rightEdge);
                this->edgeQueue.push(rightEdge);

                // Then down
                Edge* downEdge = new Edge();
                downEdge->a = currVertex;
                downEdge->b = this->vertexes[i + numCols];
                if (this->weightValue == 0) {
                    downEdge->weight = rand() % 100;
                }
                else if (this->weightValue == 1) {
                    downEdge->weight = this->generateWeight1();
                }
                else if (this->weightValue == 2) {
                    downEdge->weight = this->generateWeight2(currVertex, "down");
                }
                else if (this->weightValue == 3) {
                    downEdge->weight = this->generateWeight3();
                }
                else if (this->weightValue == 4) {
                    downEdge->weight = this->generateWeight4(currVertex);
                }
                currVertex->edges.push_back(downEdge);
                downVertex->edges.push_back(downEdge);
                this->edgeQueue.push(downEdge);

            }
            else {

                // If we are in the last column...
                // Assign vertex below as a neighbor and vise/versa
                currVertex->neighbors.push_back(this->vertexes[i + numCols]);
                this->vertexes[i+ numCols]->neighbors.push_back(currVertex);

                // Create down edge/assign weight
                Edge* downEdge = new Edge();
                downEdge->a = currVertex;
                downEdge->b = this->vertexes[i + numCols];
                if (this->weightValue == 0) {
                    downEdge->weight = rand() % 100;
                }
                else if (this->weightValue == 1) {
                    downEdge->weight = this->generateWeight1();
                }
                else if (this->weightValue == 2) {
                    downEdge->weight = this->generateWeight2(currVertex, "down");
                }
                else if (this->weightValue == 3) {
                    downEdge->weight = this->generateWeight3();
                }
                else if (this->weightValue == 4) {
                    downEdge->weight = this->generateWeight4(currVertex);
                }
                currVertex->edges.push_back(downEdge);
                this->vertexes[i + numCols]->edges.push_back(downEdge);
                this->edgeQueue.push(downEdge);

            }
        } else {
            // If we are in the last row...
            // Assign vertex to the right as a neighbor and vice/versa
            currVertex->neighbors.push_back(this->vertexes[i + 1]);
            this->vertexes[i + 1]->neighbors.push_back(currVertex);

            // Create right edge/assign weight
            Edge *rightEdge = new Edge();
            rightEdge->a = currVertex;
            rightEdge->b = this->vertexes[i + 1];
            if (this->weightValue == 0) {
                rightEdge->weight = rand() % 100;
            }
            else if (this->weightValue == 1) {
                rightEdge->weight = this->generateWeight1();
            }
            else if (this->weightValue == 2) {
                rightEdge->weight = this->generateWeight2(currVertex, "right");
            }
            else if (this->weightValue == 3) {
                rightEdge->weight = this->generateWeight3();
            }
            else if (this->weightValue == 4) {
                rightEdge->weight = this->generateWeight4(currVertex);
            }
            currVertex->edges.push_back(rightEdge);
            this->vertexes[i + 1]->edges.push_back(rightEdge);
            this->edgeQueue.push(rightEdge);
        }
    }

    // Finally, add our start and end vertex nodes
    Vertex* startVertex = new Vertex();
    Vertex* endVertex = new Vertex();
    startVertex->label = vertexes.size();
    this->vertexes.push_back(startVertex);
    endVertex->label = vertexes.size();
    this->vertexes.push_back(endVertex);
    this->start = startVertex;
    this->end = endVertex;

    // And then assign their neighbors/edges
    // The startVertex will only have one neighbor, the first vertex in the second row
    // The weight for the start/end edges is 0
    startVertex->neighbors.push_back(this->vertexes[numCols]);
    this->vertexes[numCols]->neighbors.push_back(startVertex);
    Edge* startEdge = new Edge();
    startEdge->a = startVertex;
    startEdge->b = this->vertexes[numCols];
    startEdge->weight = 0;
    startVertex->edges.push_back(startEdge);
    this->vertexes[numCols]->edges.push_back(startEdge);
    this->edgeQueue.push(startEdge);

    // The endVertex will only have one neighbor, the last vertex in the second to last row
    endVertex->neighbors.push_back(this->vertexes[(numCols * numRows) - numCols - 1]);
    this->vertexes[(numCols * numRows) - numCols - 1]->neighbors.push_back(endVertex);
    Edge* endEdge = new Edge();
    endVertex->edges.push_back(endEdge);
    endEdge->a = endVertex;
    endEdge->b = this->vertexes[(numCols * numRows) - numCols - 1];
    endEdge->weight = 0;
    endVertex->edges.push_back(endEdge);
    this->vertexes[(numCols * numRows) - numCols - 1]->edges.push_back(endEdge);
    this->edgeQueue.push(endEdge);

}

// Destructor for mazegraphs
MazeGraph::~MazeGraph() {

    // Cycle through all vertexes...
    for (int i = 0; i < this->vertexes.size(); i++) {

        // Cycle through all the edges
        for (int j = 0; j < this->vertexes[i]->edges.size(); j++) {

            // Delete the edge
            delete this->vertexes[i]->edges[j];
        }

        // Finally, delete the vertex
        delete this->vertexes[i];
    }

}

// Prints all the vertexes and their neighbors
// Should look like an adjacency list
void MazeGraph::print() {

    // Loop through all the vertexes
    for (int i = 0; i < this->vertexes.size(); i++) {

        // Print them and their neighbors
        vertexes.at(i)->printVertexNeighbors();
    }
}

// Same print function but with weights
void MazeGraph::printWeight() {

    // Loop through all the vertexes
    for (int i = 0; i < this->vertexes.size(); i++) {

        // Print them and their neighbors
        vertexes.at(i)->printWeightNeighbors();
    }
}

// Function for making sure our priority queue is being populated properly
// Only for testing purposes, do not call when running program because it will wipe the queue
void MazeGraph::printQueue() {

    // Loop through all the edges in the queue
    while (this->edgeQueue.size() > 0) {

        // Grab the next edge
        Edge* currEdge = this->edgeQueue.top();

        // Pop and print the edge
        this->edgeQueue.pop();
        std::cout <<'\n' << currEdge->a->label << " -" << currEdge->weight << "- " << currEdge->b->label;
    }
}

// Function to make the MST
void MazeGraph::makeMST() {

    // Cycle through our Adjacency List
    while(this->MST.size() < this->vertexes.size() -1) {

        // Make two poiners to the a and b vertexes of the top edge in the queue
        Vertex* a = this->_find(this->edgeQueue.top()->a);
        Vertex* b = this->_find(this->edgeQueue.top()->b);

        // Check if a is the same as b
        if(a != b){
            // If it's not, perform union and push the edge into the MST
            this->_union(a, b);
            this->MST.push_back(this->edgeQueue.top());
            this->edgeQueue.top()->isInMST = true;
        }
        // Pop the top edge off before going through the loop again
        this->edgeQueue.pop();
    }

    // Go through adjacency list and modify neighbors/edges to reflect MST
    for(int i = 0; i < this->vertexes.size(); i++){

        // Grab the current vertex
        Vertex* currVertex = this->vertexes[i];

        // Go through the edges of the vertex
        for (int j = 0; j < currVertex->edges.size(); j++) {

            // Check if current edge is in MST
            if (!currVertex->edges[j]->isInMST) {

                // Create a temp pointer
                Vertex* tempNeighbor = currVertex->neighbors.at(j);

                // Delete the edge and it's corresponding neighbor vertex
                currVertex->edges.erase(currVertex->edges.begin() + j);
                currVertex->neighbors.erase(currVertex->neighbors.begin() + j);

                // Cycle through neighbors of tempNeighbor
                for (int k = 0; k < tempNeighbor->neighbors.size(); k++) {

                    // Look for currVertex inside the neighbors of tempNeighbor
                    if (currVertex == tempNeighbor->neighbors.at(k)) {

                        // Delete the vertex and edge
                        tempNeighbor->neighbors.erase(tempNeighbor->neighbors.begin() + k);
                        tempNeighbor->edges.erase(tempNeighbor->edges.begin() + k);
                    }

                }

            }
        }
    }
}

// Union function for our MST function
void MazeGraph::_union(Vertex* v1, Vertex* v2) {

    // Make vertex 1, vertex 2's parent
    v2->parent = v1;
}

// Find function for our MST function
Vertex *MazeGraph::_find(Vertex* current) {

    // Check if we have hit the top parent
    if (current == current->parent) {
        return current;
    }

    // Make result pointer and recursively call _find on parent
    Vertex* result = _find(current->parent);
    current->parent = result;

    return result;
}

// Recursive shortest path/DFS
bool MazeGraph::shortestPath(Vertex* current) {

    // Check if we're at the end
    if (current == this->end) {
        //this->mazeSolution.push_back(current);
        return true;
    }

    // Set our current value to visited
    current->wasVisited = true;

    // Loop through our the neighbors
    for (int i = 0; i < current->neighbors.size(); i++) {

        // Check if the neighbor has been visited
        if (current->neighbors.at(i)->wasVisited == false) {

            // Recursive call to shortestPath
            if (shortestPath(current->neighbors.at(i))) {

                // Add the vertex to the solution vector
                this->mazeSolution.insert(this->mazeSolution.begin(), current->neighbors.at(i));
                return true;
            }
        }
    }
    return false;
}

// Function for printing the solution
void MazeGraph::printSolutionVector() {

    std::cout << this->mazeSolution.at(0)->label;

    // Cycle through vertexes in the solution and print
    for (int i = 1; i < this->mazeSolution.size(); i++) {

        std::cout << "-> " << this->mazeSolution.at(i)->label;
    }

    std::cout << std::endl;
}

// Print the maze with the solution
void MazeGraph::printSolutionGrid(bool solution) {

    // Calculate grid dimensions based on maze dimensions
    int row = 2 * this->numRows + 1;
    int column = 2 * this->numCols + 1;

    // Main loop: Traverse through each row of the grid
    for (int y = 0; y < row; y++) {
        std::cout << "\n";

        // Nested loop: Traverse through each column of the current row
        for (int x = 0; x < column; x++) {

            // Print top and bottom grid boundaries
            if (y == 0 || y == row - 1) {
                std::cout << "X ";
            }

            // Print the entrance (top-left) of the maze
            else if (x == 0 && y == 3) {
                if (solution) {
                    std::cout << "\033[32m" << "o " << "\033[0m";
                } else {
                    std::cout << "  ";
                }
            }

            // Print the exit (bottom-right) of the maze
            else if (x == column - 1 && y == row - 4) {
                if (solution) {
                    std::cout << "\033[32m" << "o " << "\033[0m";
                } else {
                    std::cout << "  ";
                }
            }

            // Print left and right grid boundaries
            else if (x == 0 || x == column - 1) {
                std::cout << "X ";
            }

            // Print the maze paths or solution markers
            else if (x % 2 == 1 && y % 2 == 1) { // Odd grid cells (possible vertex positions)
                int oldY = (y - 1) / 2;
                int oldX = (x - 1) / 2;
                int vertex = oldX + oldY * this->numCols;

                // Check if the current vertex is part of the solution path
                bool printSpace = true;
                for (int j = 0; j < this->mazeSolution.size(); j++) {
                    if (vertex == this->mazeSolution.at(j)->label) {
                        printSpace = false;
                        if (solution) {
                            std::cout << "\033[32m" << "o " << "\033[0m";
                        } else {
                            std::cout << "  ";
                        }
                    }
                }
                if (printSpace) {
                    std::cout << "  ";
                }
            }

            // Print vertical walls or pathways
            else if (x % 2 != 0 && y % 2 == 0) { // Odd column in even row
                int oldY = (y - 2) / 2;
                int oldX = (x - 1) / 2;
                int vertexUP = oldX + oldY * this->numCols;
                oldY = (y + 1) / 2;
                int vertexDown = oldX + oldY * this->numCols;

                // Check for an edge between the two vertices
                bool printWall = true;
                int count = 0;
                for (int i = 0; i < this->vertexes.at(vertexUP)->neighbors.size(); i++) {
                    if (this->vertexes.at(vertexUP)->neighbors.at(i)->label == vertexDown) {
                        printWall = false;
                        count = 0;

                        // Check if both vertices are part of the solution
                        for (int j = 0; j < this->mazeSolution.size(); j++) {
                            if (vertexUP == this->mazeSolution.at(j)->label) {
                                count++;
                            }
                            if (vertexDown == this->mazeSolution.at(j)->label) {
                                count++;
                            }
                        }

                        if (count == 2) {
                            if (solution) {
                                std::cout << "\033[32m" << "o " << "\033[0m";
                            } else {
                                std::cout << "  ";
                            }
                        } else {
                            std::cout << "  ";
                        }
                        break;
                    }
                }
                if (printWall) {
                    std::cout << "X ";
                }
            }

            // Print horizontal walls or pathways
            else if (x % 2 == 0 && y % 2 != 0) { // Even column in odd row
                int oldY = (y - 1) / 2;
                int oldX = (x - 1) / 2;
                int vertexLeft = oldX + oldY * this->numCols;
                oldX = x / 2;
                int vertexRight = oldX + oldY * this->numCols;

                // Check for an edge between the two vertices
                bool printWall = true;
                int count = 0;
                for (int i = 0; i < this->vertexes.at(vertexRight)->neighbors.size(); i++) {
                    if (this->vertexes.at(vertexRight)->neighbors.at(i)->label == vertexLeft) {
                        printWall = false;
                        count = 0;

                        // Check if both vertices are part of the solution
                        for (int j = 0; j < this->mazeSolution.size(); j++) {
                            if (vertexRight == this->mazeSolution.at(j)->label) {
                                count++;
                            }
                            if (vertexLeft == this->mazeSolution.at(j)->label) {
                                count++;
                            }
                        }

                        if (count == 2) {
                            if (solution) {
                                std::cout << "\033[32m" << "o " << "\033[0m";
                            } else {
                                std::cout << "  ";
                            }
                        } else {
                            std::cout << "  ";
                        }
                        break;
                    }
                }
                if (printWall) {
                    std::cout << "X ";
                }
            }

            // Default case: Print walls
            else {
                std::cout << "X ";
            }
        }
    }

    // End of grid output
    std::cout << "\n";
}

// Generates weights as going up from 1 to the number of edges
int MazeGraph::generateWeight1() {

    // Check what the previous weight was set to
    // Return that number + 1
    this->prevEdgeWeight += 1;
    return this->prevEdgeWeight;
}

// Generates weights increasing traveling down then up
// alternating each column in the graph grid
int MazeGraph::generateWeight2(Vertex* parent, std::string direction) {

    // Check the label of the parent vertex to the edge
    int parentx = parent->label % this->numCols;
    int parenty = parent->label / this->numCols;
    int weight = 999;

    // If the edge is down, return 1
    if (direction == "down") {
        weight = 1;
    }
    else {
        // Otherwise, check if we're in an even column
        if (parentx % 2 == 0) {
            // Then check if we're at the bottom row
            if (parenty == this->numCols -1) {
                weight = 1;
            }
        }
        else {
            // If we're in an odd column, check if we're at the top row
            if (parenty == 0) {
                weight = 1;
            }
        }
    }
    return weight;
}

// Generates weights that kind of look like an office building with windows
int MazeGraph::generateWeight3() {

    // Check what the previous weight was set to
    // Return a binary value based on what it was
    if (this->prevEdgeWeight == 0) {
        this->prevEdgeWeight = 1;
        return 1;
    }

    if (this->prevEdgeWeight == 1) {
        this->prevEdgeWeight = 0;
        return 0;
    }
}

// Generates a stairstep effect
int MazeGraph::generateWeight4(Vertex* parent) {

    // Check the label of the parent vertex to the edge
    int x = parent->label % numCols;
    int y = parent->label / numCols;
    int weight = 0;

    // Return proper weight based on x y position
    if ((x + y) % 2 == 0) {
        weight = 2;
    }
    else {
        weight = 4;
    }
    return weight;
}

